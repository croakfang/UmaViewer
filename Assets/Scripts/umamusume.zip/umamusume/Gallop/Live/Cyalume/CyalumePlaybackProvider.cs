using System;
using System.Collections.Generic;
using UnityEngine;

namespace Gallop.Live.Cyalume
{
    [Serializable]
    public class CyalumePlaybackData
    {
        public int DataNo;
        public int PatternId;
        public float StartTime;
        public float PlaySpeed = 1f;
        public int ChoreographyType;
    }

    public class CyalumePlaybackProvider : MonoBehaviour
    {
        public List<CyalumePlaybackData> data = new List<CyalumePlaybackData>();

        public bool TryGetCurrent(float liveTime, out CyalumePlaybackData current)
        {
            current = null;

            if (data == null || data.Count == 0)
                return false;

            for (int i = 0; i < data.Count; i++)
            {
                var item = data[i];
                if (item == null)
                    continue;

                if (item.StartTime <= liveTime)
                {
                    current = item;
                }
                else
                {
                    break;
                }
            }

            return current != null;
        }
    }
}