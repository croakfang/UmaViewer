using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using UnityEngine;
using Gallop.Live.Cutt;

namespace Gallop.Live
{
    /// <summary>
    /// Runtime blink-light driver for already-loaded live stage objects.
    ///
    /// This version follows the reverse-engineered BlinkLightController flow more closely:
    /// 1) timeline only feeds parameters/time;
    /// 2) each blink slot runs its own LightContainer-like state;
    /// 3) current slot colors are built from pattern/colorType;
    /// 4) renderers consume colors through a stable ColorIndex mapping per root.
    /// </summary>
    public class StageBlinkLightDriver : MonoBehaviour
    {
        public bool verboseLog = false;

        // UVAlphaMask: _ColorPowerMultiply
        // BlinkSimple: multiply into _ColorPower directly
        // LightAdd1:   use _ColorPowerMultiply when present
        public float emissionBoost = 1.0f;

        public float blinkSimpleUseNormalCorrection = 0f;
        public float localTimeScale = 1f;
        public float powerSmoothing = 0f;      // 0 = disabled
        public float offEps = 0.0001f;

        // Hysteresis (only used when useForceRenderingOff=true)
        public float onThreshold = 0f;
        public float offThreshold = 0f;

        // Usually safer to keep false to avoid sorting/pop issues
        public bool useForceRenderingOff = false;

        // If a root does not get a timeline callback every frame, optionally keep advancing its localTime
        public bool continueWhenNoUpdate = false;
        public float maxCatchupSecondsPerFrame = 0.2f;

        // UV / non-UV separation to reduce sort fighting
        public int uvSortingBias = 2048;
        public int rootSortingStride = 8192;

        // Stable ordering within one root
        public int stableSortStride = 4;

        // Raw Unity Light is kept optional and defaults to OFF so LED / other light systems are not overridden.
        public bool driveUnityLights = false;
        public bool neverDisableLights = true;
        public float lightMinIntensity = 0f;
        public float lightIntensityScale = 1f;

        // Timeline probe
        public bool probeTimeline = false;
        public string probeTimelineNameContains = "";
        public bool probeTimelineOncePerFrame = true;

        private const int kMaxBlinkSlots = 10;
        private int _probeFrame = -1;

        private LiveTimelineControl _ctl;
        private StageController _stage;
        private MaterialPropertyBlock _mpb;

        private Func<float> _liveNowGetter;

        private float LiveNow()
        {
            return (_liveNowGetter != null) ? _liveNowGetter() : Time.time;
        }

        private static Func<float> BuildLiveNowGetter(LiveTimelineControl ctl)
        {
            if (ctl == null) return null;

            var t = ctl.GetType();
            var p = t.GetProperty("currentLiveTime") ?? t.GetProperty("CurrentLiveTime");
            if (p != null && p.PropertyType == typeof(float))
                return () => (float)p.GetValue(ctl, null);

            var f = t.GetField("currentLiveTime") ?? t.GetField("CurrentLiveTime");
            if (f != null && f.FieldType == typeof(float))
                return () => (float)f.GetValue(ctl);

            return null;
        }

        private struct CacheItem
        {
            public LiveTimelineKeyBlinkLightData key;
            public float localTime;
            public float currentFrame;
            public float currentLiveTime;
            public int updatedFrame;
        }

        private readonly Dictionary<string, CacheItem> _latest = new Dictionary<string, CacheItem>(256);

        // Root sorting base
        private readonly Dictionary<string, int> _rootBase = new Dictionary<string, int>(256);
        private int _nextRootBase = 0;

        // Init-off
        private bool _allOffInited = false;

        // Reused temp container to avoid per-frame GC
        private readonly List<string> _tmpKeys = new List<string>(256);

        private struct GroundPick { public string root; public int frame; }
        private readonly Dictionary<string, GroundPick> _groundChosen = new Dictionary<string, GroundPick>(16);

        private sealed class LightContainerState
        {
            public int index;
            public float progressTime;
            public int randomSeedBase;
            public int pattern;

            public float basePower;
            public float powerMin;
            public float powerMax;
            public float powerDiff;

            public int loopCountMax;
            public float waitTime;
            public float turnOnTime;
            public float turnOffTime;
            public float keepTime;
            public float intervalOffset;
            public float loopTime;

            public float currentPower;
            public float currentHRatio;
            public float currentSRatio;
            public float currentVRatio;
            public int loopCount;
        }

        private sealed class BlinkRootRuntime
        {
            public string runtimeKey;
            public LiveTimelineKeyBlinkLightData key;
            public float localTime;
            public float liveTime;
            public int seedBase;
            public int lightBlendMode;
            public int pattern;
            public int colorType;

            public readonly Color[] color0 = new Color[kMaxBlinkSlots];
            public readonly Color[] color1 = new Color[kMaxBlinkSlots];
            public readonly bool[] isReverseHue = new bool[kMaxBlinkSlots];
            public readonly Vector4[] currentColors = new Vector4[kMaxBlinkSlots];
            public readonly LightContainerState[] slots = new LightContainerState[kMaxBlinkSlots];

            public BlinkRootRuntime(string runtimeKey)
            {
                this.runtimeKey = runtimeKey;
                for (int i = 0; i < kMaxBlinkSlots; i++)
                    slots[i] = new LightContainerState { index = i };
            }
        }

        // Cached component lists under each root
        private sealed class RootCache
        {
            public string rootName;
            public GameObject rootGo;
            public bool rootIsUv;
            public bool rootIsBeam;
            public bool orderByVertical;

            public bool dirty = true;
            public readonly List<RendererEntry> renderers = new List<RendererEntry>(64);
            public readonly List<LightEntry> lights = new List<LightEntry>(16);

            public int slotCount;
            public int lastRendererCount;
            public int lastLightCount;
        }

        private readonly Dictionary<string, RootCache> _rootCache = new Dictionary<string, RootCache>(256);
        private readonly Dictionary<string, BlinkRootRuntime> _runtime = new Dictionary<string, BlinkRootRuntime>(256);

        private enum IndexMode
        {
            Invalid = -1,
            LightPrefixNumber,
            SuffixNumber,
            LastDigits
        }

        private struct IndexToken
        {
            public bool valid;
            public IndexMode mode;
            public int n;

            public int ToRawIndex()
            {
                return valid ? n : -1;
            }
        }

        private struct RendererEntry
        {
            public Renderer r;

            // Stable ordering
            public int stableSlot;

            // Cached name/index
            public string cachedChildName;
            public IndexToken token;
            public int rawIndex;
            public int colorIndex;

            // Cached type
            public bool isBlinkSimple;
            public bool isUvAlphaMask;
            public bool isLightAdd1;
            public bool hasColorPowerMultiply;
            public bool wantsMpb;

            // Auto-refresh guards
            public Material[] cachedSharedMaterialsRef;
            public int cachedSharedMaterialsLen;

            // Smoothing / hysteresis state
            public bool hasSmoothed;
            public float smoothedP;
            public bool renderOnState;
        }

        private struct LightEntry
        {
            public Light l;
            public string cachedChildName;
            public IndexToken token;
            public int rawIndex;
            public int colorIndex;
        }

        private static readonly Regex ReLightPrefix = new Regex(@"^light(\d+)(?:_|$)", RegexOptions.Compiled | RegexOptions.IgnoreCase);
        private static readonly Regex ReSuffixNumber = new Regex(@"_(\d+)$", RegexOptions.Compiled);
        private static readonly Regex ReLastDigits = new Regex(@"(\d+)(?!.*\d)", RegexOptions.Compiled);

        private void Awake()
        {
            _mpb = new MaterialPropertyBlock();
        }

        private void OnEnable()
        {
            BindIfPossible();
        }

        private void OnDisable()
        {
            Unbind();
        }

        private void BindIfPossible()
        {
            var dir = Director.instance;
            _ctl = dir ? dir._liveTimelineControl : null;
            _stage = dir ? dir._stageController : null;

            if (_ctl == null || _stage == null) return;

            _liveNowGetter = BuildLiveNowGetter(_ctl);

            _ctl.OnUpdateBlinkLight += OnBlinkLight;
            if (verboseLog) Debug.Log("[StageBlinkLightDriver] bound");
        }

        private void Unbind()
        {
            if (_ctl != null) _ctl.OnUpdateBlinkLight -= OnBlinkLight;

            _ctl = null;
            _stage = null;
            _liveNowGetter = null;

            _latest.Clear();
            _rootCache.Clear();
            _runtime.Clear();

            _rootBase.Clear();
            _nextRootBase = 0;
            _allOffInited = false;

            _tmpKeys.Clear();
            _groundChosen.Clear();
        }

        private static bool IsBlinkRootName(string name)
        {
            if (string.IsNullOrEmpty(name)) return false;
            if (name.IndexOf("_spotlight3d_controller", StringComparison.OrdinalIgnoreCase) >= 0) return false;
            if (name.IndexOf("ledlight", StringComparison.OrdinalIgnoreCase) >= 0) return false;

            return name.IndexOf("_blinklight", StringComparison.OrdinalIgnoreCase) >= 0 ||
                   name.IndexOf("_blinkbeamlight", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static bool IsBeamRootName(string name)
        {
            return !string.IsNullOrEmpty(name) &&
                   name.IndexOf("_blinkbeamlight", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static bool IsProtectedLedName(string name)
        {
            return !string.IsNullOrEmpty(name) &&
                   name.IndexOf("ledlight", StringComparison.OrdinalIgnoreCase) >= 0;
        }

        private static IndexToken InvalidToken()
        {
            return new IndexToken { valid = false, mode = IndexMode.Invalid, n = 0 };
        }

        private static IndexToken ParseIndexToken(string childName)
        {
            if (string.IsNullOrEmpty(childName))
                return InvalidToken();

            var m = ReLightPrefix.Match(childName);
            if (m.Success && int.TryParse(m.Groups[1].Value, out int lightN))
                return new IndexToken { valid = true, mode = IndexMode.LightPrefixNumber, n = lightN };

            m = ReSuffixNumber.Match(childName);
            if (m.Success && int.TryParse(m.Groups[1].Value, out int suffixN))
                return new IndexToken { valid = true, mode = IndexMode.SuffixNumber, n = suffixN };

            m = ReLastDigits.Match(childName);
            if (m.Success && int.TryParse(m.Groups[1].Value, out int lastN))
                return new IndexToken { valid = true, mode = IndexMode.LastDigits, n = lastN };

            return InvalidToken();
        }

        private void OnBlinkLight(ref BlinkLightUpdateInfo info)
        {
            string rootName = (info.data != null) ? info.data.name : null;
            if (string.IsNullOrEmpty(rootName) || info.key == null) return;
            if (!IsBlinkRootName(rootName)) return;

            if (probeTimeline)
            {
                bool ok = string.IsNullOrEmpty(probeTimelineNameContains) ||
                          rootName.IndexOf(probeTimelineNameContains, StringComparison.OrdinalIgnoreCase) >= 0;

                if (ok)
                {
                    int f = Time.frameCount;
                    if (!probeTimelineOncePerFrame || _probeFrame != f)
                    {
                        _probeFrame = f;
                        Debug.Log($"[TL] frame={f} root={rootName} localTime={info.localTime:F6} keyFrame={info.key.frame}");
                    }
                }
            }

            _latest[rootName] = new CacheItem
            {
                key = info.key,
                localTime = Mathf.Max(0f, info.localTime),
                currentFrame = info.currentFrame,
                currentLiveTime = info.currentLiveTime,
                updatedFrame = Time.frameCount
            };
        }

        private void LateUpdate()
        {
            if (_ctl == null || _stage == null)
                BindIfPossible();

            if (_ctl == null || _stage == null || _stage.StageObjectMap == null) return;

            if (!_allOffInited)
            {
                InitAllStageLightsOff();
                _allOffInited = true;
            }

            if (_latest.Count == 0) return;

            EnforceGroundPanelExclusive();

            if (continueWhenNoUpdate)
            {
                float dt = Mathf.Min(Time.deltaTime, maxCatchupSecondsPerFrame);
                if (dt > 0f)
                {
                    _tmpKeys.Clear();
                    foreach (var k in _latest.Keys) _tmpKeys.Add(k);

                    for (int i = 0; i < _tmpKeys.Count; i++)
                    {
                        var key = _tmpKeys[i];
                        var item = _latest[key];
                        if (item.updatedFrame != Time.frameCount)
                        {
                            item.localTime += dt;
                            _latest[key] = item;
                        }
                    }
                }
            }

            foreach (var kv in _latest)
            {
                string rootName = kv.Key;
                if (!IsBlinkRootName(rootName))
                    continue;

                var item = kv.Value;
                float localTimeNow = item.localTime * Mathf.Max(0.0001f, localTimeScale);
                float liveNow = item.currentLiveTime;

                if (_stage.StageObjectUnitMap.TryGetValue(rootName, out var unit) &&
                    unit != null && unit.ChildObjects != null && unit.ChildObjects.Length > 0)
                {
                    for (int i = 0; i < unit.ChildObjects.Length; i++)
                    {
                        var childPrefab = unit.ChildObjects[i];
                        if (childPrefab == null) continue;

                        if (_stage.StageObjectMap.TryGetValue(childPrefab.name, out var realGo) && realGo != null)
                        {
                            string runtimeKey = rootName + "__U" + i;
                            ApplyToRootCached(runtimeKey, realGo, item.key, localTimeNow, liveNow, item.currentFrame);
                        }
                    }
                }
                else if (_stage.StageObjectMap.TryGetValue(rootName, out var rootGo) && rootGo != null)
                {
                    ApplyToRootCached(rootName, rootGo, item.key, localTimeNow, liveNow, item.currentFrame);
                }
            }
        }

        private BlinkRootRuntime GetOrCreateRuntime(string runtimeKey)
        {
            if (!_runtime.TryGetValue(runtimeKey, out var rt) || rt == null)
            {
                rt = new BlinkRootRuntime(runtimeKey);
                _runtime[runtimeKey] = rt;
            }
            return rt;
        }

        private RootCache GetOrBuildRootCache(string rootName, GameObject rootGo)
        {
            if (!_rootCache.TryGetValue(rootName, out var rc) || rc == null)
            {
                rc = new RootCache { rootName = rootName };
                _rootCache[rootName] = rc;
            }

            if (rc.rootGo != rootGo)
            {
                rc.rootGo = rootGo;
                rc.rootIsUv = rootName.IndexOf("_uv", StringComparison.OrdinalIgnoreCase) >= 0;
                rc.rootIsBeam = IsBeamRootName(rootName);
                rc.dirty = true;
            }

            if (rc.dirty)
                BuildRootCache(rc);

            return rc;
        }

        private void BuildRootCache(RootCache rc)
        {
            rc.renderers.Clear();
            rc.lights.Clear();
            rc.slotCount = 0;

            if (rc.rootGo == null || !IsBlinkRootName(rc.rootName))
            {
                rc.dirty = false;
                return;
            }

            rc.rootIsUv = rc.rootName.IndexOf("_uv", StringComparison.OrdinalIgnoreCase) >= 0;
            rc.rootIsBeam = IsBeamRootName(rc.rootName);

            var pendingRenderers = new List<RendererEntry>(64);
            var pendingLights = new List<LightEntry>(16);
            var rawIndices = new SortedSet<int>();
            var rawPositions = new Dictionary<int, Vector3>(16);
            float minX = float.PositiveInfinity, maxX = float.NegativeInfinity;
            float minY = float.PositiveInfinity, maxY = float.NegativeInfinity;

            var transforms = rc.rootGo.GetComponentsInChildren<Transform>(true);
            for (int i = 0; i < transforms.Length; i++)
            {
                var t = transforms[i];
                if (t == null) continue;

                var go = t.gameObject;
                if (go == null || go == rc.rootGo) continue;

                string childName = go.name ?? "";
                if (IsProtectedLedName(childName)) continue;

                var token = ParseIndexToken(childName);
                if (!token.valid) continue;

                int rawIndex = token.ToRawIndex();
                if (rawIndex < 0) continue;
                rawIndices.Add(rawIndex);
                if (!rawPositions.ContainsKey(rawIndex))
                {
                    Vector3 lp = t.localPosition;
                    rawPositions[rawIndex] = lp;
                    if (lp.x < minX) minX = lp.x;
                    if (lp.x > maxX) maxX = lp.x;
                    if (lp.y < minY) minY = lp.y;
                    if (lp.y > maxY) maxY = lp.y;
                }

                var r = t.GetComponent<Renderer>();
                if (r != null)
                {
                    bool isBlinkSimple, isUvAlphaMask, isLightAdd1, hasColorPowerMultiply;
                    DetectType(r, out isBlinkSimple, out isUvAlphaMask, out isLightAdd1, out hasColorPowerMultiply);

                    var mats = r.sharedMaterials;
                    pendingRenderers.Add(new RendererEntry
                    {
                        r = r,
                        stableSlot = pendingRenderers.Count,
                        cachedChildName = childName,
                        token = token,
                        rawIndex = rawIndex,
                        colorIndex = -1,
                        isBlinkSimple = isBlinkSimple,
                        isUvAlphaMask = isUvAlphaMask,
                        isLightAdd1 = isLightAdd1,
                        hasColorPowerMultiply = hasColorPowerMultiply,
                        wantsMpb = (isBlinkSimple || isUvAlphaMask || isLightAdd1),
                        cachedSharedMaterialsRef = mats,
                        cachedSharedMaterialsLen = (mats != null) ? mats.Length : 0,
                        hasSmoothed = false,
                        smoothedP = 0f,
                        renderOnState = false
                    });
                }

                if (driveUnityLights)
                {
                    var l = t.GetComponent<Light>();
                    if (l != null)
                    {
                        pendingLights.Add(new LightEntry
                        {
                            l = l,
                            cachedChildName = childName,
                            token = token,
                            rawIndex = rawIndex,
                            colorIndex = -1
                        });
                    }
                }
            }

            bool forceVertical = rc.rootName.IndexOf("vertical", StringComparison.OrdinalIgnoreCase) >= 0;
            bool forceHorizontal = rc.rootName.IndexOf("horizontal", StringComparison.OrdinalIgnoreCase) >= 0 ||
                                   rc.rootName.IndexOf("center", StringComparison.OrdinalIgnoreCase) >= 0;
            float spanX = (rawPositions.Count > 0) ? (maxX - minX) : 0f;
            float spanY = (rawPositions.Count > 0) ? (maxY - minY) : 0f;
            rc.orderByVertical = forceVertical || (!forceHorizontal && spanY > spanX * 1.15f);

            var sortedRaw = new List<int>(rawIndices);
            sortedRaw.Sort((a, b) =>
            {
                Vector3 pa = rawPositions.TryGetValue(a, out var va) ? va : Vector3.zero;
                Vector3 pb = rawPositions.TryGetValue(b, out var vb) ? vb : Vector3.zero;
                if (rc.orderByVertical)
                {
                    int cy = pb.y.CompareTo(pa.y);
                    if (cy != 0) return cy;
                    int cx = pa.x.CompareTo(pb.x);
                    if (cx != 0) return cx;
                }
                else
                {
                    int cx = pa.x.CompareTo(pb.x);
                    if (cx != 0) return cx;
                    int cy = pb.y.CompareTo(pa.y);
                    if (cy != 0) return cy;
                }
                return a.CompareTo(b);
            });

            var rawToSlot = new Dictionary<int, int>(sortedRaw.Count);
            int slot = 0;
            foreach (int raw in sortedRaw)
            {
                if (slot >= kMaxBlinkSlots) break;
                rawToSlot[raw] = slot++;
            }
            rc.slotCount = Mathf.Clamp(slot, 0, kMaxBlinkSlots);

            for (int i = 0; i < pendingRenderers.Count; i++)
            {
                var e = pendingRenderers[i];
                if (rawToSlot.TryGetValue(e.rawIndex, out int colorIndex))
                {
                    e.colorIndex = colorIndex;
                    rc.renderers.Add(e);
                }
            }

            for (int i = 0; i < pendingLights.Count; i++)
            {
                var le = pendingLights[i];
                if (rawToSlot.TryGetValue(le.rawIndex, out int colorIndex))
                {
                    le.colorIndex = colorIndex;
                    rc.lights.Add(le);
                }
            }

            rc.lastRendererCount = rc.renderers.Count;
            rc.lastLightCount = rc.lights.Count;
            rc.dirty = false;

            if (verboseLog)
                Debug.Log($"[StageBlinkLightDriver] cache built root={rc.rootName} beam={rc.rootIsBeam} verticalOrder={rc.orderByVertical} slots={rc.slotCount} R={rc.renderers.Count} L={rc.lights.Count}");
        }

        private void InitAllStageLightsOff()
        {
            foreach (var kv in _stage.StageObjectMap)
            {
                string name = kv.Key;
                var go = kv.Value;
                if (go == null) continue;
                if (!IsBlinkRootName(name)) continue;

                ApplyRootOffCached(name, go);
            }

            if (verboseLog) Debug.Log("[StageBlinkLightDriver] InitAllStageLightsOff done");
        }

        private void EnforceGroundPanelExclusive()
        {
            _groundChosen.Clear();

            foreach (var kv in _latest)
            {
                string rootName = kv.Key;
                string g = GetGroundPanelGroupBase(rootName);
                if (g == null) continue;

                var item = kv.Value;
                if (!_groundChosen.TryGetValue(g, out var cur) || item.updatedFrame > cur.frame)
                    _groundChosen[g] = new GroundPick { root = rootName, frame = item.updatedFrame };
            }

            if (_groundChosen.Count == 0) return;

            foreach (var kv in _stage.StageObjectMap)
            {
                string name = kv.Key;
                var go = kv.Value;
                if (go == null) continue;

                string g = GetGroundPanelGroupBase(name);
                if (g == null) continue;

                if (_groundChosen.TryGetValue(g, out var pick) && name != pick.root)
                    ApplyRootOffCached(name, go);
            }
        }

        private static string GetGroundPanelGroupBase(string rootName)
        {
            int i = rootName.IndexOf("_blinklight_ground_panel", StringComparison.Ordinal);
            if (i < 0) return null;
            return rootName.Substring(0, i + "_blinklight_ground_panel".Length);
        }

        private int GetRootBase(string rootName)
        {
            if (_rootBase.TryGetValue(rootName, out int b)) return b;
            b = _nextRootBase;
            _nextRootBase += rootSortingStride;
            _rootBase[rootName] = b;
            return b;
        }

        private void ApplyToRootCached(string runtimeKey, GameObject rootGo, LiveTimelineKeyBlinkLightData k, float localTimeNow, float liveNow, float currentFrame)
        {
            var rc = GetOrBuildRootCache(runtimeKey, rootGo);
            if (rc.slotCount <= 0) return;

            var rt = GetOrCreateRuntime(runtimeKey);
            ApplyUpdateInfoToRuntime(rt, rc.slotCount, k, localTimeNow, liveNow, currentFrame);
            BuildCurrentColors(rt, rc.slotCount);

            int baseOrder = GetRootBase(runtimeKey);
            int stride = Mathf.Max(1, stableSortStride);

            for (int i = 0; i < rc.renderers.Count; i++)
            {
                var e = rc.renderers[i];
                var r = e.r;
                if (r == null)
                {
                    rc.dirty = true;
                    continue;
                }

                string childName = r.gameObject ? r.gameObject.name : "";
                if (!ReferenceEquals(childName, e.cachedChildName) && childName != e.cachedChildName)
                {
                    e.cachedChildName = childName;
                    e.token = ParseIndexToken(childName);
                    e.rawIndex = e.token.ToRawIndex();
                    rc.dirty = true;
                }

                int slotIndex = e.colorIndex;
                if (slotIndex < 0 || slotIndex >= rc.slotCount)
                {
                    rc.renderers[i] = e;
                    continue;
                }

                var mats = r.sharedMaterials;
                int matsLen = (mats != null) ? mats.Length : 0;
                if (mats != e.cachedSharedMaterialsRef || matsLen != e.cachedSharedMaterialsLen)
                {
                    bool isBlinkSimple, isUvAlphaMask, isLightAdd1, hasColorPowerMultiply;
                    DetectType(r, out isBlinkSimple, out isUvAlphaMask, out isLightAdd1, out hasColorPowerMultiply);

                    e.isBlinkSimple = isBlinkSimple;
                    e.isUvAlphaMask = isUvAlphaMask;
                    e.isLightAdd1 = isLightAdd1;
                    e.hasColorPowerMultiply = hasColorPowerMultiply;
                    e.wantsMpb = (isBlinkSimple || isUvAlphaMask || isLightAdd1);

                    e.cachedSharedMaterialsRef = mats;
                    e.cachedSharedMaterialsLen = matsLen;
                }

                Vector4 slotColor = rt.currentColors[slotIndex];
                float pRaw = Mathf.Max(0f, slotColor.magnitude > 0f ? rt.slots[slotIndex].currentPower : 0f);

                float p = pRaw;
                if (powerSmoothing > 0f)
                {
                    float a = 1f - Mathf.Exp(-powerSmoothing * Time.deltaTime);
                    if (!e.hasSmoothed)
                    {
                        e.hasSmoothed = true;
                        e.smoothedP = pRaw;
                    }
                    else
                    {
                        e.smoothedP = Mathf.Lerp(e.smoothedP, pRaw, a);
                    }
                    p = e.smoothedP;
                }

                Color currentColor = new Color(slotColor.x, slotColor.y, slotColor.z, 1f);

                int uvBias = (rc.rootIsUv || e.isUvAlphaMask) ? uvSortingBias : 0;
                r.sortingOrder = baseOrder + uvBias + e.stableSlot * stride;
                r.enabled = true;

                if (e.wantsMpb)
                {
                    if (useForceRenderingOff)
                    {
                        float onTh = Mathf.Max(0f, onThreshold);
                        float offTh = Mathf.Clamp(offThreshold, 0f, onTh);

                        if (!e.renderOnState && p >= onTh) e.renderOnState = true;
                        else if (e.renderOnState && p <= offTh) e.renderOnState = false;

                        r.forceRenderingOff = !e.renderOnState;
                    }
                    else
                    {
                        r.forceRenderingOff = false;
                    }

                    ApplyMpbToRenderer(
                        r, currentColor, p, rt.liveTime,
                        e.isBlinkSimple, e.isUvAlphaMask, e.isLightAdd1, e.hasColorPowerMultiply);
                }
                else
                {
                    r.forceRenderingOff = false;
                }

                rc.renderers[i] = e;
            }

            if (driveUnityLights && rc.lights != null)
            {
                for (int i = 0; i < rc.lights.Count; i++)
                {
                    var le = rc.lights[i];
                    var l = le.l;
                    if (l == null)
                    {
                        rc.dirty = true;
                        continue;
                    }

                    string childName = l.gameObject ? l.gameObject.name : "";
                    if (!ReferenceEquals(childName, le.cachedChildName) && childName != le.cachedChildName)
                    {
                        le.cachedChildName = childName;
                        le.token = ParseIndexToken(childName);
                        le.rawIndex = le.token.ToRawIndex();
                        rc.dirty = true;
                    }

                    int slotIndex = le.colorIndex;
                    if (slotIndex < 0 || slotIndex >= rc.slotCount)
                    {
                        rc.lights[i] = le;
                        continue;
                    }

                    Vector4 slotColor = rt.currentColors[slotIndex];
                    float p = Mathf.Max(0f, rt.slots[slotIndex].currentPower);
                    Color currentColor = new Color(slotColor.x, slotColor.y, slotColor.z, 1f);

                    if (neverDisableLights) l.enabled = true;
                    else l.enabled = (p > offEps);

                    l.color = currentColor;
                    l.intensity = Mathf.Max(lightMinIntensity, p) * lightIntensityScale;

                    rc.lights[i] = le;
                }
            }
        }

        private void ApplyUpdateInfoToRuntime(BlinkRootRuntime rt, int slotCount, LiveTimelineKeyBlinkLightData k, float localTimeNow, float liveNow, float currentFrame)
        {
            rt.key = k;
            rt.localTime = Mathf.Max(0f, localTimeNow);
            rt.liveTime = liveNow;
            int keyFrame = (k != null) ? k.frame : 0;
            rt.seedBase = StableHash32(StableHash32(rt.runtimeKey.GetHashCode(), keyFrame), slotCount);
            rt.lightBlendMode = (k != null) ? k.LightBlendMode : 0;
            rt.pattern = (k != null) ? k.pattern : 0;
            rt.colorType = (k != null) ? k.colorType : 0;

            CopyColors(rt.color0, k != null ? k.color0Array : null, Color.white);
            CopyColors(rt.color1, k != null ? k.color1Array : null, Color.white);
            CopyReverseHue(rt.isReverseHue, k != null ? k.isReverseHueArray : null);

            for (int i = 0; i < slotCount; i++)
            {
                var s = rt.slots[i];
                s.index = i;
                s.progressTime = rt.localTime;
                s.randomSeedBase = StableHash32(rt.seedBase, PickInt(k != null ? k.CmnColorType0Array : null, i, i));
                s.pattern = rt.pattern;
                s.basePower = Mathf.Max(0f, PickFloat(k != null ? k.powerArray : null, i, 1f));
                s.powerMin = Mathf.Max(0f, k != null ? k.powerMin : 0f);
                s.powerMax = Mathf.Max(0f, k != null ? k.powerMax : s.basePower);
                s.powerDiff = Mathf.Max(0f, s.powerMax - s.powerMin);
                s.loopCountMax = Mathf.Max(0, k != null ? k.loopCount : 0);
                s.waitTime = Mathf.Max(0f, k != null ? k.waitTime : 0f);
                s.turnOnTime = Mathf.Max(0.05f, k != null ? k.turnOnTime : 0.05f);
                s.turnOffTime = Mathf.Max(0.05f, k != null ? k.turnOffTime : 0.05f);
                s.keepTime = Mathf.Max(0f, k != null ? k.keepTime : 0f);

                float interval = Mathf.Max(0f, k != null ? k.intervalTime : 0f);
                switch (rt.pattern)
                {
                    case 1:
                        s.intervalOffset = GetDeterministicRatio01(s.index, s.randomSeedBase) * interval;
                        break;
                    case 2:
                        s.intervalOffset = i * interval;
                        break;
                    case 3:
                        s.intervalOffset = (slotCount - i - 1) * interval;
                        break;
                    default:
                        s.intervalOffset = 0f;
                        break;
                }

                s.loopTime = s.turnOnTime + s.keepTime + s.turnOffTime + s.intervalOffset;
                UpdateSlotState(s);
            }

            for (int i = slotCount; i < kMaxBlinkSlots; i++)
            {
                var s = rt.slots[i];
                s.index = i;
                s.progressTime = 0f;
                s.randomSeedBase = rt.seedBase;
                s.pattern = 0;
                s.basePower = 0f;
                s.powerMin = 0f;
                s.powerMax = 0f;
                s.powerDiff = 0f;
                s.loopCountMax = 0;
                s.waitTime = 0f;
                s.turnOnTime = 0.05f;
                s.turnOffTime = 0.05f;
                s.keepTime = 0f;
                s.intervalOffset = 0f;
                s.loopTime = 0f;
                s.currentPower = 0f;
                s.currentHRatio = 0f;
                s.currentSRatio = 0f;
                s.currentVRatio = 0f;
                s.loopCount = 0;
                rt.currentColors[i] = Vector4.zero;
            }
        }

        private static void UpdateSlotState(LightContainerState s)
        {
            int pattern = s.pattern;
            if (pattern >= 1 && pattern <= 3)
            {
                if (s.intervalOffset > 0f && s.intervalOffset > s.progressTime)
                {
                    s.currentPower = 0f;
                    s.loopCount = 0;
                    s.currentHRatio = 0f;
                    s.currentSRatio = 0f;
                    s.currentVRatio = 0f;
                    return;
                }

                float loopTime = Mathf.Max(0.0001f, s.loopTime);
                float local = s.progressTime - s.intervalOffset;
                int loopCount = Mathf.FloorToInt(local / loopTime);
                s.loopCount = loopCount;

                bool forceOff = false;
                bool isLastLoop = false;
                if (s.loopCountMax > 0)
                {
                    if (loopCount < s.loopCountMax)
                    {
                        isLastLoop = (loopCount == s.loopCountMax - 1);
                    }
                    else
                    {
                        forceOff = true;
                        s.loopCount = s.loopCountMax - 1;
                    }
                }

                s.currentHRatio = GetDeterministicRatio01(s.index, s.randomSeedBase + 3 * s.loopCount + 0);
                s.currentSRatio = GetDeterministicRatio01(s.index, s.randomSeedBase + 3 * s.loopCount + 1);
                s.currentVRatio = GetDeterministicRatio01(s.index, s.randomSeedBase + 3 * s.loopCount + 2);

                if (forceOff)
                {
                    s.currentPower = 0f;
                    return;
                }

                float phase = local - s.loopCount * loopTime;
                if (phase < s.turnOnTime)
                {
                    float u = phase / Mathf.Max(0.0001f, s.turnOnTime);
                    s.currentPower = (s.loopCount > 0)
                        ? (u * s.powerDiff + s.powerMin)
                        : (u * s.powerMax);
                    return;
                }

                if (phase < s.turnOnTime + s.keepTime)
                {
                    s.currentPower = s.powerMax;
                    return;
                }

                if (phase < s.turnOnTime + s.keepTime + s.turnOffTime)
                {
                    float u = 1f - ((phase - (s.turnOnTime + s.keepTime)) / Mathf.Max(0.0001f, s.turnOffTime));
                    s.currentPower = isLastLoop
                        ? (u * s.powerMax)
                        : (u * s.powerDiff + s.powerMin);
                    return;
                }

                s.currentPower = isLastLoop ? 0f : s.powerMin;
            }
            else
            {
                s.currentPower = s.basePower;
                s.currentHRatio = 0f;
                s.currentSRatio = 0f;
                s.currentVRatio = 0f;
                s.loopCount = 0;
            }
        }

        private static void BuildCurrentColors(BlinkRootRuntime rt, int slotCount)
        {
            for (int i = 0; i < slotCount; i++)
            {
                var s = rt.slots[i];
                float p = Mathf.Max(0f, s.currentPower);
                Color outColor;

                if (rt.pattern == 0)
                {
                    outColor = SafeColor(rt.color0, i, Color.white);
                }
                else
                {
                    switch (rt.colorType)
                    {
                        case 1:
                            {
                                int src = (i + slotCount - PositiveMod(s.loopCount, slotCount)) % slotCount;
                                outColor = SafeColor(rt.color0, src, Color.white);
                                break;
                            }
                        case 2:
                            {
                                int src = (i + PositiveMod(s.loopCount, slotCount)) % slotCount;
                                outColor = SafeColor(rt.color0, src, Color.white);
                                break;
                            }
                        case 3:
                            outColor = ((s.loopCount & 1) != 0)
                                ? SafeColor(rt.color1, i, Color.white)
                                : SafeColor(rt.color0, i, Color.white);
                            break;
                        default:
                            outColor = GetBlinkColor(
                                SafeColor(rt.color0, i, Color.white),
                                SafeColor(rt.color1, i, Color.white),
                                s.currentHRatio,
                                s.currentSRatio,
                                s.currentVRatio,
                                rt.isReverseHue[i]);
                            break;
                    }
                }

                rt.currentColors[i] = new Vector4(outColor.r * p, outColor.g * p, outColor.b * p, 0f);
            }
        }

        private void ApplyRootOffCached(string rootName, GameObject rootGo)
        {
            var rc = GetOrBuildRootCache(rootName, rootGo);

            for (int i = 0; i < rc.renderers.Count; i++)
            {
                var e = rc.renderers[i];
                var r = e.r;
                if (r == null)
                {
                    rc.dirty = true;
                    continue;
                }

                r.enabled = true;

                if (e.wantsMpb)
                {
                    r.forceRenderingOff = useForceRenderingOff;
                    e.renderOnState = false;
                    e.hasSmoothed = false;
                    e.smoothedP = 0f;

                    _mpb.Clear();

                    if (e.isUvAlphaMask)
                    {
                        _mpb.SetColor("_MulColor0", Color.black);
                        _mpb.SetColor("_MulColor1", Color.black);
                        _mpb.SetFloat("_ColorPower", 0f);
                        _mpb.SetFloat("_ColorPowerMultiply", emissionBoost);
                        _mpb.SetFloat("_AppTime", LiveNow());
                    }
                    else if (e.isLightAdd1)
                    {
                        _mpb.SetColor("_MulColor0", Color.black);
                        _mpb.SetColor("_MulColor1", Color.black);
                        _mpb.SetFloat("_ColorPower", 0f);
                        if (e.hasColorPowerMultiply) _mpb.SetFloat("_ColorPowerMultiply", emissionBoost);
                    }
                    else if (e.isBlinkSimple)
                    {
                        _mpb.SetColor("_BlinkLightColor", Color.black);
                        _mpb.SetFloat("_ColorPower", 0f);
                        _mpb.SetFloat("_UseNormalCorrection", blinkSimpleUseNormalCorrection);
                    }

                    r.SetPropertyBlock(_mpb);
                }
                else
                {
                    r.forceRenderingOff = false;
                }

                rc.renderers[i] = e;
            }

            if (driveUnityLights && rc.lights != null)
            {
                for (int i = 0; i < rc.lights.Count; i++)
                {
                    var le = rc.lights[i];
                    var l = le.l;
                    if (l == null)
                    {
                        rc.dirty = true;
                        continue;
                    }

                    if (neverDisableLights) l.enabled = true;
                    else l.enabled = false;

                    l.intensity = 0f;
                    rc.lights[i] = le;
                }
            }
        }

        private void ApplyMpbToRenderer(
            Renderer r,
            Color currentColor,
            float p,
            float liveNow,
            bool isBlinkSimple,
            bool isUvAlphaMask,
            bool isLightAdd1,
            bool hasColorPowerMultiply)
        {
            _mpb.Clear();

            if (isUvAlphaMask)
            {
                _mpb.SetColor("_MulColor0", currentColor);
                _mpb.SetColor("_MulColor1", currentColor);
                _mpb.SetFloat("_ColorPower", p);
                _mpb.SetFloat("_ColorPowerMultiply", emissionBoost);
                _mpb.SetFloat("_AppTime", liveNow);
            }
            else if (isLightAdd1)
            {
                _mpb.SetColor("_MulColor0", currentColor);
                _mpb.SetColor("_MulColor1", currentColor);
                _mpb.SetFloat("_ColorPower", p);
                if (hasColorPowerMultiply) _mpb.SetFloat("_ColorPowerMultiply", emissionBoost);
            }
            else if (isBlinkSimple)
            {
                _mpb.SetColor("_BlinkLightColor", currentColor);
                _mpb.SetFloat("_ColorPower", p * emissionBoost);
                _mpb.SetFloat("_UseNormalCorrection", blinkSimpleUseNormalCorrection);
            }

            r.SetPropertyBlock(_mpb);
        }

        private void DetectType(
            Renderer r,
            out bool isBlinkSimple,
            out bool isUvAlphaMask,
            out bool isLightAdd1,
            out bool hasColorPowerMultiply)
        {
            isBlinkSimple = false;
            isUvAlphaMask = false;
            isLightAdd1 = false;
            hasColorPowerMultiply = false;

            var mats = r.sharedMaterials;
            if (mats == null) return;

            bool hasBlinkColor = false, hasColorPower = false, hasMul0 = false, hasMul1 = false, hasMultiply = false;

            for (int i = 0; i < mats.Length; i++)
            {
                var m = mats[i];
                if (m == null) continue;

                var sh = m.shader;
                string sn = sh ? (sh.name ?? "") : "";

                if (sn.IndexOf("UVAlphaMask", StringComparison.OrdinalIgnoreCase) >= 0) isUvAlphaMask = true;
                if (sn.IndexOf("LightBlinkSimple", StringComparison.OrdinalIgnoreCase) >= 0) isBlinkSimple = true;
                if (!isUvAlphaMask && sn.IndexOf("LightAdd1", StringComparison.OrdinalIgnoreCase) >= 0) isLightAdd1 = true;

                if (m.HasProperty("_BlinkLightColor")) hasBlinkColor = true;
                if (m.HasProperty("_ColorPower")) hasColorPower = true;
                if (m.HasProperty("_MulColor0")) hasMul0 = true;
                if (m.HasProperty("_MulColor1")) hasMul1 = true;
                if (m.HasProperty("_ColorPowerMultiply")) hasMultiply = true;
            }

            if (!isBlinkSimple && hasBlinkColor && hasColorPower) isBlinkSimple = true;
            if (!isUvAlphaMask && hasMul0 && hasMul1 && hasColorPower && hasMultiply) isUvAlphaMask = true;
            if (!isLightAdd1 && !isUvAlphaMask && hasMul0 && hasMul1 && hasColorPower) isLightAdd1 = true;

            hasColorPowerMultiply = hasMultiply;
        }

        private static int StableHash32(int a, int b)
        {
            unchecked
            {
                uint x = 2166136261u;
                x = (x ^ (uint)a) * 16777619u;
                x = (x ^ (uint)b) * 16777619u;
                x ^= x >> 13;
                x *= 1274126177u;
                x ^= x >> 16;
                return (int)x;
            }
        }

        private static float GetDeterministicRatio01(int a, int b)
        {
            unchecked
            {
                uint x = 2166136261u;
                x = (x ^ (uint)(a + 1)) * 16777619u;
                x = (x ^ (uint)(b + 1)) * 16777619u;
                x ^= x >> 13;
                x *= 1274126177u;
                x ^= x >> 16;
                return (x & 0x00FFFFFFu) / 16777215.0f;
            }
        }

        private static Color GetBlinkColor(Color color0, Color color1, float hueRatio, float saturationRatio, float valueRatio, bool isReverseHue)
        {
            Color.RGBToHSV(color0, out float h0, out float s0, out float v0);
            Color.RGBToHSV(color1, out float h1, out float s1, out float v1);

            float h;
            if (isReverseHue)
            {
                float delta = h1 - h0;
                if (Mathf.Abs(delta) < 1e-6f)
                {
                    h = h0;
                }
                else
                {
                    if (delta > 0f) delta -= 1f;
                    else delta += 1f;
                    h = Mathf.Repeat(h0 + delta * hueRatio, 1f);
                }
            }
            else
            {
                h = Mathf.LerpAngle(h0 * 360f, h1 * 360f, hueRatio) / 360f;
                h = Mathf.Repeat(h, 1f);
            }

            float s = Mathf.Lerp(s0, s1, saturationRatio);
            float v = Mathf.Lerp(v0, v1, valueRatio);
            return Color.HSVToRGB(h, Mathf.Clamp01(s), Mathf.Clamp01(v));
        }

        private static int PositiveMod(int a, int b)
        {
            if (b <= 0) return 0;
            int m = a % b;
            return (m < 0) ? (m + b) : m;
        }

        private static void CopyColors(Color[] dst, Color[] src, Color fill)
        {
            Color last = fill;
            for (int i = 0; i < kMaxBlinkSlots; i++)
            {
                if (src != null && i < src.Length)
                    last = src[i];
                dst[i] = last;
            }
        }

        private static void CopyReverseHue(bool[] dst, int[] src)
        {
            bool last = false;
            for (int i = 0; i < kMaxBlinkSlots; i++)
            {
                if (src != null && i < src.Length)
                    last = src[i] != 0;
                dst[i] = last;
            }
        }

        private static Color SafeColor(Color[] arr, int idx, Color fallback)
        {
            if (arr == null || arr.Length == 0) return fallback;
            idx = Mathf.Clamp(idx, 0, arr.Length - 1);
            return arr[idx];
        }

        private static int PickInt(int[] arr, int idx, int fallback)
        {
            if (arr == null || arr.Length == 0) return fallback;
            idx = Mathf.Clamp(idx, 0, arr.Length - 1);
            return arr[idx];
        }

        private static float PickFloat(float[] arr, int idx, float fallback)
        {
            if (arr == null || arr.Length == 0) return fallback;
            idx = Mathf.Clamp(idx, 0, arr.Length - 1);
            return arr[idx];
        }
    }
}
